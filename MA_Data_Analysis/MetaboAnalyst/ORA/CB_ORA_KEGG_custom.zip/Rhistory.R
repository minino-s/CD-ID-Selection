# PID of current job: 2789827
mSet<-InitDataObjects("conc", "msetora", FALSE, 150)
cmpd.vec<-c("C00325","HMDB0000033","HMDB0000036","HMDB0000045","HMDB0000052","HMDB0000056","HMDB0000062","HMDB0000064","HMDB0000086","HMDB0000121","HMDB0000125","HMDB0000182","HMDB0000190","HMDB0000210","HMDB0000211","HMDB0000214","HMDB0000217","HMDB0000220","HMDB0000239","HMDB0000243","HMDB0000251","HMDB0000252","HMDB0000269","HMDB0000285","HMDB0000288","HMDB0000290","HMDB0000292","HMDB0000501","HMDB0000510","HMDB0000517","HMDB0000538","HMDB0000625","HMDB0000660","HMDB0000673","HMDB0000684","HMDB0000714","HMDB0000763","HMDB0000806","HMDB0000812","HMDB0000827","HMDB0000848","HMDB0000895","HMDB0000896","HMDB0000902","HMDB0000965","HMDB0001015","HMDB0001058","HMDB0001068","HMDB0001178","HMDB0001185","HMDB0001201","HMDB0001206","HMDB0001248","HMDB0001262","HMDB0001273","HMDB0001316","HMDB0001341","HMDB0001342","HMDB0001397","HMDB0001406","HMDB0001423","HMDB0001429","HMDB0001487","HMDB0001539","HMDB0001545","HMDB0001546","HMDB0001548","HMDB0001564","HMDB0002931","HMDB00030","HMDB0003337","HMDB0003464","HMDB00097","HMDB0010382","HMDB0011745","HMDB0012097","HMDB0015186","HMDB0029419","HMDB0033865","HMDB00355","HMDB0036749","HMDB00671","HMDB00773","HMDB00824","HMDB00935","HMDB01067","HMDB01325","HMDB02368","HMDB0250863","HMDB0254735","HMDB03045")
mSet<-Setup.MapData(mSet, cmpd.vec);
mSet<-CrossReferencing(mSet, "hmdb_kegg", mixed = T);
mSet<-CreateMappingResultTable(mSet)
mSet<-Setup.HMDBReferenceMetabolome(mSet, "background_pathway_kegg_list.txt");
mSet<-Setup.HMDBReferenceMetabolome(mSet, "background_ORA_names.txt");
mSet<-SetMetabolomeFilter(mSet, T);
mSet<-SetCurrentMsetLib(mSet, "kegg_pathway", 2);
mSet<-CalculateHyperScore(mSet)
PlotORAMembership(mSet, "mset_membership_0_", "png", 150)
mSet<-PlotORA(mSet, "ora_0_", "net", "png", 150, width=NA)
PlotORA(mSet, "ora_0_", "net", "png", 150)
mSet<-PlotEnrichDotPlot(mSet, "ora", "ora_dot_0_", "png", 150, width=NA)
PlotEnrichDotPlot(mSet, "ora", "ora_dot_0_", "png", 150)
mSet<-CalculateHyperScore(mSet)
PlotORAMembership(mSet, "mset_membership_0_", "png", 150)
mSet<-PlotORA(mSet, "ora_1_", "net", "png", 150, width=NA)
PlotORA(mSet, "ora_1_", "net", "png", 150)
mSet<-PlotEnrichDotPlot(mSet, "ora", "ora_dot_1_", "png", 150, width=NA)
PlotEnrichDotPlot(mSet, "ora", "ora_dot_1_", "png", 150)
