# PID of current job: 2522340
mSet<-InitDataObjects("conc", "pathora", FALSE, 150)
cmpd.vec<-c("HMDB0000045","HMDB0000072","HMDB0000086","HMDB0000126","HMDB0000285","HMDB0000290","HMDB0000510","HMDB0000625","HMDB0000806","HMDB0000895","HMDB0001058","HMDB0001068","HMDB0001178","HMDB0001262","HMDB0001273","HMDB0001316","HMDB0001342","HMDB0001367","HMDB0001401","HMDB0001487","HMDB0001511","HMDB0001564","HMDB0002931","HMDB0003464","HMDB0007218","HMDB00097","HMDB0011745","HMDB0028704","HMDB0028736","HMDB0028813","HMDB0028880","HMDB0028949","HMDB0029419","HMDB0036749","HMDB00766","HMDB00773","HMDB00824","HMDB00935","HMDB01163","HMDB0250863","HMDB0252569","HMDB11756")
mSet<-Setup.MapData(mSet, cmpd.vec);
mSet<-CrossReferencing(mSet, "hmdb");
mSet<-CreateMappingResultTable(mSet)
mSet<-Setup.KEGGReferenceMetabolome(mSet, "background_pathway_kegg_list.txt");
mSet<-SetKEGG.PathLib(mSet, "hsa", "current")
mSet<-SetMetabolomeFilter(mSet, T);
mSet<-CalculateOraScore(mSet, "rbc", "fisher")
mSet<-PlotPathSummary(mSet, F, "path_view_0_", "png", 150, width=NA, NA, NA )
PlotPathSummary(mSet, FALSE, "path_view_0_", "png", 150)
mSet<-PlotPathSummaryGG(mSet, F, "path_view_0_", "png", 300, width=NA )
